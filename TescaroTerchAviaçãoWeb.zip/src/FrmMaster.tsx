import { FunctionComponent } from "react";
import styles from "./css/FrmMaster.module.css";

export const FrmMaster: FunctionComponent = () => {
  return (
    <div className={styles.frmMasterDiv}>
      <div className={styles.menuDiv}>
        <div className={styles.frameDiv} />
        <div className={styles.frameDiv1} />
        <div className={styles.frameDiv2} />
      </div>
      <div className={styles.bodyDiv}>
        <div className={styles.pnlTopDiv}>
          <button className={styles.btnHamburguerButton} />
        </div>
        <div className={styles.corpoDiv} />
      </div>
    </div>
  );
};
